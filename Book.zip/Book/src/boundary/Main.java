package boundary;

public class Main {
	public static void main(String args[]){
		
		//System.out.println("Hello world");
		SQLConnector connection = new SQLConnector(); 
		connection.DisplayData(); 
	}
}
